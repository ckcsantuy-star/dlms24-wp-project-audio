// DLMS-24 · WP PROJECT AUDIO — WiFi AP/STA, web server, WebSocket, OTA, penyimpanan
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/semphr.h"
#include "esp_system.h"
#include "esp_log.h"
#include "esp_wifi.h"
#include "esp_event.h"
#include "esp_netif.h"
#include "esp_http_server.h"
#include "esp_ota_ops.h"
#include "nvs_flash.h"
#include "nvs.h"
#include "driver/gpio.h"
#include "config.h"
#include "state.h"
#include "dsp.h"

static const char *TAG = "dlms";

extern const uint8_t index_html_start[]    asm("_binary_index_html_start");
extern const uint8_t index_html_end[]      asm("_binary_index_html_end");
extern const uint8_t manifest_json_start[] asm("_binary_manifest_json_start");
extern const uint8_t manifest_json_end[]   asm("_binary_manifest_json_end");

static httpd_handle_t srv;
static SemaphoreHandle_t wsm, stm;
static state_t g_st;
static volatile bool dirty;
static volatile TickType_t last_chg;
static char sta_ip[16] = "";
static bool sta_ok = false, have_sta = false;
static int sta_retry = 0;

// ---------------- WiFi ----------------
static void wev(void *a, esp_event_base_t b, int32_t id, void *d) {
    if (b == WIFI_EVENT && id == WIFI_EVENT_STA_START && have_sta) esp_wifi_connect();
    else if (b == WIFI_EVENT && id == WIFI_EVENT_STA_DISCONNECTED) {
        sta_ok = false;
        if (have_sta && sta_retry++ < 10) esp_wifi_connect();
    } else if (b == IP_EVENT && id == IP_EVENT_STA_GOT_IP) {
        ip_event_got_ip_t *e = d;
        snprintf(sta_ip, sizeof sta_ip, IPSTR, IP2STR(&e->ip_info.ip));
        sta_ok = true; sta_retry = 0;
    }
}

static void wifi_start(void) {
    char ssid[33] = "", pass[65] = "";
    nvs_handle_t h;
    if (nvs_open("dlms", NVS_READONLY, &h) == ESP_OK) {
        size_t n = sizeof ssid; nvs_get_str(h, "ssid", ssid, &n);
        n = sizeof pass; nvs_get_str(h, "pass", pass, &n);
        nvs_close(h);
    }
    have_sta = ssid[0] != 0;
    ESP_ERROR_CHECK(esp_netif_init());
    ESP_ERROR_CHECK(esp_event_loop_create_default());
    esp_netif_create_default_wifi_ap();
    esp_netif_create_default_wifi_sta();
    wifi_init_config_t cfg = WIFI_INIT_CONFIG_DEFAULT();
    ESP_ERROR_CHECK(esp_wifi_init(&cfg));
    ESP_ERROR_CHECK(esp_event_handler_register(WIFI_EVENT, ESP_EVENT_ANY_ID, wev, NULL));
    ESP_ERROR_CHECK(esp_event_handler_register(IP_EVENT, IP_EVENT_STA_GOT_IP, wev, NULL));
    wifi_config_t ap = { .ap = { .channel = 6, .max_connection = 4, .authmode = WIFI_AUTH_WPA2_PSK } };
    strcpy((char *)ap.ap.ssid, AP_SSID); ap.ap.ssid_len = strlen(AP_SSID);
    strcpy((char *)ap.ap.password, AP_PASS);
    ESP_ERROR_CHECK(esp_wifi_set_mode(have_sta ? WIFI_MODE_APSTA : WIFI_MODE_AP));
    ESP_ERROR_CHECK(esp_wifi_set_config(WIFI_IF_AP, &ap));
    if (have_sta) {
        wifi_config_t st = {0};
        strncpy((char *)st.sta.ssid, ssid, sizeof st.sta.ssid - 1);
        strncpy((char *)st.sta.password, pass, sizeof st.sta.password - 1);
        ESP_ERROR_CHECK(esp_wifi_set_config(WIFI_IF_STA, &st));
    }
    ESP_ERROR_CHECK(esp_wifi_start());
    esp_wifi_set_ps(WIFI_PS_NONE);
}

// ---------------- WebSocket util ----------------
static void ws_send_fd(int fd, const char *s) {
    httpd_ws_frame_t f = { .type = HTTPD_WS_TYPE_TEXT, .payload = (uint8_t *)s, .len = strlen(s) };
    xSemaphoreTake(wsm, portMAX_DELAY);
    httpd_ws_send_frame_async(srv, fd, &f);
    xSemaphoreGive(wsm);
}
static void ws_bcast(const char *s, int skip) {
    int fds[8]; size_t n = 8;
    if (!srv || httpd_get_client_list(srv, &n, fds) != ESP_OK) return;
    for (size_t i = 0; i < n; i++)
        if (fds[i] != skip && httpd_ws_get_fd_info(srv, fds[i]) == HTTPD_WS_CLIENT_WEBSOCKET) ws_send_fd(fds[i], s);
}
static char *state_msg(const state_t *s, int from) {
    cJSON *r = cJSON_CreateObject();
    cJSON_AddStringToObject(r, "t", "state");
    cJSON_AddNumberToObject(r, "from", from);
    cJSON_AddItemToObject(r, "s", state_to_json(s));
    char *o = cJSON_PrintUnformatted(r);
    cJSON_Delete(r);
    return o;
}
static void send_info(int fd) {
    char b[120];
    snprintf(b, sizeof b, "{\"t\":\"info\",\"ip\":\"%s\",\"mode\":\"%s\"}", sta_ok ? sta_ip : "192.168.4.1", sta_ok ? "WiFi rumah" : "Access Point");
    ws_send_fd(fd, b);
}
static void toast(int fd, const char *m) {
    char b[120]; snprintf(b, sizeof b, "{\"t\":\"toast\",\"m\":\"%s\"}", m); ws_send_fd(fd, b);
}
static void mark_dirty(void) { dirty = true; last_chg = xTaskGetTickCount(); }

static void restart_task(void *a) { vTaskDelay(pdMS_TO_TICKS(1500)); esp_restart(); }

static void handle_msg(int fd, char *txt) {
    cJSON *r = cJSON_Parse(txt);
    if (!r) return;
    const char *t = cJSON_GetStringValue(cJSON_GetObjectItemCaseSensitive(r, "t"));
    if (!t) goto done;
    if (!strcmp(t, "state")) {
        cJSON *s = cJSON_GetObjectItemCaseSensitive(r, "s");
        state_t ns;
        xSemaphoreTake(stm, portMAX_DELAY); ns = g_st; xSemaphoreGive(stm);
        if (s && state_from_json(s, &ns)) {
            xSemaphoreTake(stm, portMAX_DELAY); g_st = ns; xSemaphoreGive(stm);
            dsp_apply(&ns);
            mark_dirty();
            cJSON_AddNumberToObject(r, "from", fd);
            char *o = cJSON_PrintUnformatted(r);
            if (o) { ws_bcast(o, fd); free(o); }
        }
    } else if (!strcmp(t, "save") || !strcmp(t, "load")) {
        cJSON *nn = cJSON_GetObjectItemCaseSensitive(r, "n");
        int n = cJSON_IsNumber(nn) ? nn->valueint : 0;
        if (n < 1 || n > 32) { toast(fd, "Slot 1-32"); goto done; }
        char key[8]; snprintf(key, sizeof key, "u%d", n);
        char m[48];
        if (!strcmp(t, "save")) {
            state_t c; xSemaphoreTake(stm, portMAX_DELAY); c = g_st; xSemaphoreGive(stm);
            snprintf(m, sizeof m, state_save(key, &c) ? "Tersimpan di slot U%d" : "Gagal simpan slot U%d", n);
            toast(fd, m);
        } else {
            state_t c;
            if (!state_load(key, &c)) { snprintf(m, sizeof m, "Slot U%d kosong", n); toast(fd, m); goto done; }
            xSemaphoreTake(stm, portMAX_DELAY); g_st = c; xSemaphoreGive(stm);
            dsp_apply(&c); mark_dirty();
            char *o = state_msg(&c, -1);
            if (o) { ws_bcast(o, -2); free(o); }
            snprintf(m, sizeof m, "Slot U%d dimuat", n); toast(fd, m);
        }
    } else if (!strcmp(t, "wifi")) {
        const char *ss = cJSON_GetStringValue(cJSON_GetObjectItemCaseSensitive(r, "ssid"));
        const char *pw = cJSON_GetStringValue(cJSON_GetObjectItemCaseSensitive(r, "pass"));
        nvs_handle_t h;
        if (ss && pw && strlen(ss) < 33 && strlen(pw) < 65 && nvs_open("dlms", NVS_READWRITE, &h) == ESP_OK) {
            nvs_set_str(h, "ssid", ss); nvs_set_str(h, "pass", pw); nvs_commit(h); nvs_close(h);
            toast(fd, "WiFi disimpan, perangkat restart");
            xTaskCreate(restart_task, "rst", 2048, NULL, 5, NULL);
        }
    }
done:
    cJSON_Delete(r);
}

static esp_err_t ws_handler(httpd_req_t *req) {
    int fd = httpd_req_to_sockfd(req);
    if (req->method == HTTP_GET) {
        char b[48]; snprintf(b, sizeof b, "{\"t\":\"hi\",\"id\":%d}", fd);
        ws_send_fd(fd, b);
        state_t c; xSemaphoreTake(stm, portMAX_DELAY); c = g_st; xSemaphoreGive(stm);
        char *m = state_msg(&c, -1);
        if (m) { ws_send_fd(fd, m); free(m); }
        send_info(fd);
        return ESP_OK;
    }
    httpd_ws_frame_t f; memset(&f, 0, sizeof f); f.type = HTTPD_WS_TYPE_TEXT;
    esp_err_t e = httpd_ws_recv_frame(req, &f, 0);
    if (e != ESP_OK) return e;
    if (f.len == 0) return ESP_OK;
    if (f.len > 12288) return ESP_FAIL;
    uint8_t *buf = malloc(f.len + 1);
    if (!buf) return ESP_ERR_NO_MEM;
    f.payload = buf;
    e = httpd_ws_recv_frame(req, &f, f.len);
    if (e == ESP_OK && f.type == HTTPD_WS_TYPE_TEXT) { buf[f.len] = 0; handle_msg(fd, (char *)buf); }
    free(buf);
    return e;
}

// ---------------- HTTP ----------------
static esp_err_t h_index(httpd_req_t *req) {
    httpd_resp_set_type(req, "text/html; charset=utf-8");
    httpd_resp_set_hdr(req, "Cache-Control", "no-cache");
    return httpd_resp_send(req, (const char *)index_html_start, index_html_end - index_html_start - 1);
}
static esp_err_t h_manifest(httpd_req_t *req) {
    httpd_resp_set_type(req, "application/manifest+json");
    return httpd_resp_send(req, (const char *)manifest_json_start, manifest_json_end - manifest_json_start - 1);
}
static esp_err_t h_ota(httpd_req_t *req) {
    const esp_partition_t *p = esp_ota_get_next_update_partition(NULL);
    esp_ota_handle_t h;
    if (!p || esp_ota_begin(p, OTA_SIZE_UNKNOWN, &h) != ESP_OK) { httpd_resp_send_err(req, HTTPD_500_INTERNAL_SERVER_ERROR, "OTA begin gagal"); return ESP_FAIL; }
    char *buf = malloc(2048);
    int rem = req->content_len;
    while (rem > 0) {
        int r = httpd_req_recv(req, buf, rem < 2048 ? rem : 2048);
        if (r == HTTPD_SOCK_ERR_TIMEOUT) continue;
        if (r <= 0 || esp_ota_write(h, buf, r) != ESP_OK) { esp_ota_abort(h); free(buf); httpd_resp_send_err(req, HTTPD_500_INTERNAL_SERVER_ERROR, "OTA tulis gagal"); return ESP_FAIL; }
        rem -= r;
    }
    free(buf);
    if (esp_ota_end(h) != ESP_OK || esp_ota_set_boot_partition(p) != ESP_OK) { httpd_resp_send_err(req, HTTPD_500_INTERNAL_SERVER_ERROR, "Firmware tidak valid"); return ESP_FAIL; }
    httpd_resp_sendstr(req, "OK, restart");
    xTaskCreate(restart_task, "rst", 2048, NULL, 5, NULL);
    return ESP_OK;
}
static esp_err_t h_404(httpd_req_t *req, httpd_err_code_t err) {
    httpd_resp_set_status(req, "302 Found");
    httpd_resp_set_hdr(req, "Location", "/");
    return httpd_resp_send(req, NULL, 0);
}

static void http_start(void) {
    httpd_config_t c = HTTPD_DEFAULT_CONFIG();
    c.max_open_sockets = 7; c.lru_purge_enable = true; c.stack_size = 8192;
    c.send_wait_timeout = 2; c.recv_wait_timeout = 5; c.core_id = 0;
    ESP_ERROR_CHECK(httpd_start(&srv, &c));
    httpd_uri_t u1 = { .uri = "/", .method = HTTP_GET, .handler = h_index };
    httpd_uri_t u2 = { .uri = "/manifest.json", .method = HTTP_GET, .handler = h_manifest };
    httpd_uri_t u3 = { .uri = "/update", .method = HTTP_POST, .handler = h_ota };
    httpd_uri_t u4 = { .uri = "/ws", .method = HTTP_GET, .handler = ws_handler, .is_websocket = true };
    httpd_register_uri_handler(srv, &u1);
    httpd_register_uri_handler(srv, &u2);
    httpd_register_uri_handler(srv, &u3);
    httpd_register_uri_handler(srv, &u4);
    httpd_register_err_handler(srv, HTTPD_404_NOT_FOUND, h_404);
}

// ---------------- task latar ----------------
static void meter_task(void *a) {
    char b[200]; int cnt = 0; float d[NCH];
    for (;;) {
        vTaskDelay(pdMS_TO_TICKS(33));
        dsp_levels(d);
        snprintf(b, sizeof b, "{\"t\":\"m\",\"v\":[%.1f,%.1f,%.1f,%.1f,%.1f,%.1f]}", d[0], d[1], d[2], d[3], d[4], d[5]);
        ws_bcast(b, -1);
        if (++cnt >= 30) {
            cnt = 0;
            snprintf(b, sizeof b, "{\"t\":\"cpu\",\"v\":%d,\"lat\":%.1f}", (int)(dsp_cpu() + .5f), dsp_latency_ms());
            ws_bcast(b, -1);
        }
    }
}
static void save_task(void *a) {
    for (;;) {
        vTaskDelay(pdMS_TO_TICKS(500));
        if (dirty && (xTaskGetTickCount() - last_chg) > pdMS_TO_TICKS(3000)) {
            dirty = false;
            state_t c; xSemaphoreTake(stm, portMAX_DELAY); c = g_st; xSemaphoreGive(stm);
            state_save("cur", &c);
        }
    }
}

void app_main(void) {
    esp_err_t e = nvs_flash_init();
    if (e == ESP_ERR_NVS_NO_FREE_PAGES || e == ESP_ERR_NVS_NEW_VERSION_FOUND) { nvs_flash_erase(); nvs_flash_init(); }
    wsm = xSemaphoreCreateMutex(); stm = xSemaphoreCreateMutex();

    gpio_config_t led = { .pin_bit_mask = 1ULL << PIN_LED, .mode = GPIO_MODE_OUTPUT };
    gpio_config(&led); gpio_set_level(PIN_LED, 0);
    gpio_config_t bt = { .pin_bit_mask = 1ULL << PIN_BTN, .mode = GPIO_MODE_INPUT, .pull_up_en = GPIO_PULLUP_ENABLE };
    gpio_config(&bt);
    int held = 0;
    for (int i = 0; i < 30; i++) { if (!gpio_get_level(PIN_BTN)) held++; vTaskDelay(pdMS_TO_TICKS(100)); }
    if (held >= 30) {
        nvs_handle_t h;
        if (nvs_open("dlms", NVS_READWRITE, &h) == ESP_OK) { nvs_erase_key(h, "ssid"); nvs_erase_key(h, "pass"); nvs_commit(h); nvs_close(h); }
        ESP_LOGW(TAG, "WiFi rumah direset");
    }

    if (!state_load("cur", &g_st)) state_default(&g_st);
    dsp_apply(&g_st);
    dsp_start();
    wifi_start();
    http_start();
    xTaskCreate(meter_task, "meter", 4096, NULL, 4, NULL);
    xTaskCreate(save_task, "save", 4096, NULL, 3, NULL);
    gpio_set_level(PIN_LED, 1);
    ESP_LOGI(TAG, "DLMS-24 siap. AP '%s' -> http://192.168.4.1", AP_SSID);
}
