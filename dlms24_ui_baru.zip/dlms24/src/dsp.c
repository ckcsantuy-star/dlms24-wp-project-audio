// DLMS-24 DSP: PEQ 8 band + crossover (HPF/LPF) + FX + kompresor + delay + limiter
// Rumus biquad identik dengan Web UI (RBJ cookbook) agar grafik = suara.
#include "dsp.h"
#include <math.h>
#include <string.h>
#include "driver/i2s_std.h"
#include "driver/gpio.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_heap_caps.h"
#include "esp_timer.h"
#include "esp_log.h"

static const char *TAG = "dsp";
#define DLEN  9728      // >= 200 ms @48k
#define FXLEN 24576     // >= 500 ms (echo)
#define CLEN  2048      // buffer chorus (dalam pool FX)

enum { T_PK, T_LS, T_HS, T_NT, T_AP, T_LP, T_HP };

typedef struct {
    uint16_t en;
    float c[NSLOT][5];
    float gain;            // linear bertanda (polaritas), 0 jika mute
    int   dly;             // sampel
    uint8_t fx; float mix, fa, fb;
    float fxc[2][5];
    float th, ratio, lim;
} chp_t;

typedef struct {
    float z[NSLOT][2];
    float gcur;
    float *dl; int dlw;
    float *fx; int fxw; uint8_t fxk;
    float fz[2][2];
    int   ri[6]; float rfs[4];
    float lfo;
    float env, cg, ct, lg;
} chr_t;

static const float XQ[6][4] = {{.7071f}, {.5412f, 1.3066f}, {.5f}, {.7071f, .7071f},
                               {.5412f, 1.3066f, .5412f, 1.3066f}, {.5774f}};
static const int XN[6] = {1, 2, 1, 2, 4, 1};

// ---------------- koefisien ----------------
static void rbj(int t, double f, double Q, double dB, float *o) {
    if (f < 10) f = 10;
    if (f > FS_HZ * 0.45) f = FS_HZ * 0.45;
    double A = pow(10, dB / 40), w = 2 * M_PI * f / FS_HZ, c = cos(w), s = sin(w), al = s / (2 * Q), sA = sqrt(A);
    double b0 = 1, b1 = 0, b2 = 0, a0 = 1, a1 = 0, a2 = 0;
    switch (t) {
    case T_LP: b0 = (1 - c) / 2; b1 = 1 - c; b2 = b0; a0 = 1 + al; a1 = -2 * c; a2 = 1 - al; break;
    case T_HP: b0 = (1 + c) / 2; b1 = -(1 + c); b2 = b0; a0 = 1 + al; a1 = -2 * c; a2 = 1 - al; break;
    case T_PK: b0 = 1 + al * A; b1 = -2 * c; b2 = 1 - al * A; a0 = 1 + al / A; a1 = -2 * c; a2 = 1 - al / A; break;
    case T_NT: b0 = 1; b1 = -2 * c; b2 = 1; a0 = 1 + al; a1 = -2 * c; a2 = 1 - al; break;
    case T_AP: b0 = 1 - al; b1 = -2 * c; b2 = 1 + al; a0 = 1 + al; a1 = -2 * c; a2 = 1 - al; break;
    case T_LS:
        b0 = A * ((A + 1) - (A - 1) * c + 2 * sA * al); b1 = 2 * A * ((A - 1) - (A + 1) * c);
        b2 = A * ((A + 1) - (A - 1) * c - 2 * sA * al);
        a0 = (A + 1) + (A - 1) * c + 2 * sA * al; a1 = -2 * ((A - 1) + (A + 1) * c);
        a2 = (A + 1) + (A - 1) * c - 2 * sA * al; break;
    case T_HS:
        b0 = A * ((A + 1) + (A - 1) * c + 2 * sA * al); b1 = -2 * A * ((A - 1) + (A + 1) * c);
        b2 = A * ((A + 1) + (A - 1) * c - 2 * sA * al);
        a0 = (A + 1) - (A - 1) * c + 2 * sA * al; a1 = 2 * ((A - 1) - (A + 1) * c);
        a2 = (A + 1) - (A - 1) * c - 2 * sA * al; break;
    }
    o[0] = b0 / a0; o[1] = b1 / a0; o[2] = b2 / a0; o[3] = a1 / a0; o[4] = a2 / a0;
}

static void build_chp(const chs_t *s, chp_t *p, int out) {
    memset(p, 0, sizeof *p);
    for (int i = 0; i < NPEQ; i++) {
        const peq_t *b = &s->peq[i];
        if (b->t == T_NT || b->t == T_AP || b->g != 0) { rbj(b->t, b->f, b->q, b->g, p->c[i]); p->en |= 1u << i; }
    }
    if (s->hpf.f > 20) for (int k = 0; k < XN[s->hpf.t % 6]; k++) { rbj(T_HP, s->hpf.f, XQ[s->hpf.t % 6][k], 0, p->c[8 + k]); p->en |= 1u << (8 + k); }
    if (s->lpf.f < 20000) for (int k = 0; k < XN[s->lpf.t % 6]; k++) { rbj(T_LP, s->lpf.f, XQ[s->lpf.t % 6][k], 0, p->c[12 + k]); p->en |= 1u << (12 + k); }
    p->gain = s->mute ? 0.f : powf(10.f, s->gain / 20.f) * (s->pol ? -1.f : 1.f);
    int d = (int)lroundf(s->dly * FS_HZ / 1000.f);
    p->dly = d < 0 ? 0 : (d > DLEN - BLOCK - 1 ? DLEN - BLOCK - 1 : d);
    p->ratio = 1; p->lim = 1;
    if (out) {
        p->fx = s->fx; p->mix = s->mix; p->fa = s->fa; p->fb = s->fb;
        p->th = s->th; p->ratio = s->ratio; p->lim = powf(10.f, s->lim / 20.f);
        float m = s->mix / 100.f, A = s->fa / 100.f;
        if (s->fx == 4) rbj(T_LP, 60 + A * 140, .7071, 0, p->fxc[0]);
        else if (s->fx == 5) rbj(T_HP, 2000 + A * 6000, .7071, 0, p->fxc[0]);
        else if (s->fx == 6) { rbj(T_LS, 60 + A * 190, .7, 10 * m, p->fxc[0]); rbj(T_HS, 10000, .7, 5 * m, p->fxc[1]); }
    }
}

// ---------------- primitif ----------------
static inline float bq1(const float *c, float *z, float in) {
    float y = c[0] * in + z[0];
    z[0] = c[1] * in - c[3] * y + z[1];
    z[1] = c[2] * in - c[4] * y;
    return y;
}
static void bq_run(float *x, int n, const float *c, float *z) {
    float b0 = c[0], b1 = c[1], b2 = c[2], a1 = c[3], a2 = c[4], z1 = z[0], z2 = z[1];
    for (int i = 0; i < n; i++) {
        float in = x[i], y = b0 * in + z1;
        z1 = b1 * in - a1 * y + z2;
        z2 = b2 * in - a2 * y;
        x[i] = y;
    }
    z[0] = z1; z[1] = z2;
}

static float g_ca, g_cr;

// ---------------- FX ----------------
static const int CL[4] = {1687, 1747, 1613, 1553}, CO[4] = {0, 1687, 3434, 5047};
static const int AL[2] = {556, 441}, AO[2] = {6600, 7156};

static void fx_run(chr_t *r, const chp_t *p, float *x) {
    if (p->fx != r->fxk) {
        memset(r->fx, 0, FXLEN * sizeof(float));
        memset(r->fz, 0, sizeof r->fz); memset(r->ri, 0, sizeof r->ri); memset(r->rfs, 0, sizeof r->rfs);
        r->fxw = 0; r->lfo = 0; r->fxk = p->fx;
    }
    float m = p->mix * .01f, A = p->fa * .01f, B = p->fb * .01f;
    switch (p->fx) {
    case 1: { // Echo
        int D = (int)((0.05f + A * 0.45f) * FS_HZ); if (D > FXLEN - 1) D = FXLEN - 1;
        float fb = B * .85f; int w = r->fxw;
        for (int i = 0; i < BLOCK; i++) {
            int rd = w - D; if (rd < 0) rd += FXLEN;
            float d = r->fx[rd];
            r->fx[w] = x[i] + d * fb;
            if (++w >= FXLEN) w = 0;
            x[i] += d * m;
        }
        r->fxw = w; break; }
    case 2: { // Reverb (Schroeder/Freeverb ringkas)
        float fbk = 0.7f + 0.28f * A, damp = B * 0.4f;
        for (int i = 0; i < BLOCK; i++) {
            float in = x[i] * 0.03f, sum = 0;
            for (int k = 0; k < 4; k++) {
                float *b = r->fx + CO[k]; int j = r->ri[k];
                float o = b[j];
                r->rfs[k] = o * (1 - damp) + r->rfs[k] * damp;
                b[j] = in + r->rfs[k] * fbk;
                if (++j >= CL[k]) j = 0;
                r->ri[k] = j; sum += o;
            }
            for (int k = 0; k < 2; k++) {
                float *b = r->fx + AO[k]; int j = r->ri[4 + k];
                float bo = b[j], o = -sum + bo;
                b[j] = sum + bo * 0.5f;
                if (++j >= AL[k]) j = 0;
                r->ri[4 + k] = j; sum = o;
            }
            x[i] += sum * m * 2.f;
        }
        break; }
    case 3: { // Chorus
        float depth = A * 0.008f * FS_HZ, base = 0.015f * FS_HZ, inc = 2.f * (float)M_PI * (0.2f + B * 2.8f) / FS_HZ;
        int w = r->fxw;
        for (int i = 0; i < BLOCK; i++) {
            r->lfo += inc; if (r->lfo > 2.f * (float)M_PI) r->lfo -= 2.f * (float)M_PI;
            r->fx[w] = x[i];
            float pos = (float)w - (base + depth * sinf(r->lfo));
            while (pos < 0) pos += CLEN;
            int i0 = (int)pos; float fr = pos - i0; int i1 = i0 + 1;
            i0 %= CLEN; i1 %= CLEN;
            float d = r->fx[i0] * (1 - fr) + r->fx[i1] * fr;
            if (++w >= CLEN) w = 0;
            x[i] += d * m;
        }
        r->fxw = w; break; }
    case 4:  // Bass enhancer
        for (int i = 0; i < BLOCK; i++) x[i] += tanhf(3.f * bq1(p->fxc[0], r->fz[0], x[i])) * 0.5f * m;
        break;
    case 5:  // Exciter
        for (int i = 0; i < BLOCK; i++) x[i] += tanhf(4.f * bq1(p->fxc[0], r->fz[0], x[i])) * 0.5f * m;
        break;
    case 6:  // Loudness
        for (int i = 0; i < BLOCK; i++) x[i] = bq1(p->fxc[1], r->fz[1], bq1(p->fxc[0], r->fz[0], x[i]));
        break;
    default: break;
    }
}

static void comp_run(chr_t *r, const chp_t *p, float *x) {
    if (p->ratio <= 1.05f) { r->cg = 1; r->ct = 1; return; }
    float k = 1.f - 1.f / p->ratio;
    for (int i = 0; i < BLOCK; i++) {
        float a = fabsf(x[i]);
        r->env += (a - r->env) * (a > r->env ? g_ca : g_cr);
        if ((i & 3) == 0) {
            float ov = 20.f * log10f(r->env + 1e-9f) - p->th;
            r->ct = ov > 0 ? powf(10.f, -ov * k / 20.f) : 1.f;
        }
        r->cg += (r->ct - r->cg) * 0.2f;
        x[i] *= r->cg;
    }
}

static void ch_proc(chr_t *r, const chp_t *p, float *x, int out) {
    for (int s = 0; s < NSLOT; s++) {
        if (p->en & (1u << s)) bq_run(x, BLOCK, p->c[s], r->z[s]);
        else r->z[s][0] = r->z[s][1] = 0;
    }
    if (out) { fx_run(r, p, x); comp_run(r, p, x); }
    int w = r->dlw;
    for (int i = 0; i < BLOCK; i++) {
        r->dl[w] = x[i];
        int rd = w - p->dly; if (rd < 0) rd += DLEN;
        x[i] = r->dl[rd];
        if (++w >= DLEN) w = 0;
    }
    r->dlw = w;
    float g = r->gcur, tg = p->gain;
    for (int i = 0; i < BLOCK; i++) { g += (tg - g) * 0.003f; x[i] *= g; }
    r->gcur = g;
    if (out) {   // limiter: attack instan, release 50 ms
        float t = p->lim, lg = r->lg;
        for (int i = 0; i < BLOCK; i++) {
            float a = fabsf(x[i]);
            float need = a > t ? t / a : 1.f;
            if (need < lg) lg = need; else lg += (1.f - lg) * (1.f / (0.05f * FS_HZ));
            float y = x[i] * lg;
            x[i] = y > 0.9999f ? 0.9999f : (y < -0.9999f ? -0.9999f : y);
        }
        r->lg = lg;
    }
}

// ---------------- state bersama ----------------
static chp_t g_pend[NCH];
static uint8_t g_pmx[4][2];
static volatile int g_dirty;
static portMUX_TYPE g_mux = portMUX_INITIALIZER_UNLOCKED;
static volatile float g_peak[NCH];
static volatile float g_cpu;

void dsp_apply(const state_t *s) {
    chp_t tmp[NCH];
    for (int i = 0; i < NCH; i++) build_chp(&s->ch[i], &tmp[i], i >= 2);
    taskENTER_CRITICAL(&g_mux);
    memcpy(g_pend, tmp, sizeof tmp);
    memcpy(g_pmx, s->mx, sizeof g_pmx);
    g_dirty = 1;
    taskEXIT_CRITICAL(&g_mux);
}

void dsp_levels(float db[NCH]) {
    for (int i = 0; i < NCH; i++) { float p = g_peak[i]; g_peak[i] = 0; db[i] = 20.f * log10f(p + 1e-9f); }
}
float dsp_cpu(void) { return g_cpu; }
float dsp_latency_ms(void) { return 4.f * BLOCK * 1000.f / FS_HZ + 0.8f; }  // perkiraan, ukur dengan loopback

// ---------------- I2S ----------------
static i2s_chan_handle_t tx0, rx0, tx1;

static void i2s_setup(void) {
    i2s_chan_config_t c0 = I2S_CHANNEL_DEFAULT_CONFIG(I2S_NUM_0, CLK_MASTER_EXT ? I2S_ROLE_SLAVE : I2S_ROLE_MASTER);
    c0.dma_desc_num = DMA_DESC; c0.dma_frame_num = BLOCK; c0.auto_clear = true;
    ESP_ERROR_CHECK(i2s_new_channel(&c0, &tx0, &rx0));
    i2s_std_config_t s0 = {
        .clk_cfg = I2S_STD_CLK_DEFAULT_CONFIG(FS_HZ),
        .slot_cfg = I2S_STD_PHILIPS_SLOT_DEFAULT_CONFIG(I2S_DATA_BIT_WIDTH_32BIT, I2S_SLOT_MODE_STEREO),
        .gpio_cfg = { .mclk = CLK_MASTER_EXT ? I2S_GPIO_UNUSED : PIN_MCLK, .bclk = PIN_BCK, .ws = PIN_WS,
                      .dout = PIN_DOUT0, .din = PIN_DIN, .invert_flags = {0} },
    };
    s0.clk_cfg.mclk_multiple = I2S_MCLK_MULTIPLE_256;
    ESP_ERROR_CHECK(i2s_channel_init_std_mode(tx0, &s0));
    ESP_ERROR_CHECK(i2s_channel_init_std_mode(rx0, &s0));

    // I2S1: slave TX untuk DAC2, clock dari kawat BCK/WS yang sama
    i2s_chan_config_t c1 = I2S_CHANNEL_DEFAULT_CONFIG(I2S_NUM_1, I2S_ROLE_SLAVE);
    c1.dma_desc_num = DMA_DESC; c1.dma_frame_num = BLOCK; c1.auto_clear = true;
    ESP_ERROR_CHECK(i2s_new_channel(&c1, &tx1, NULL));
    i2s_std_config_t s1 = {
        .clk_cfg = I2S_STD_CLK_DEFAULT_CONFIG(FS_HZ),
        .slot_cfg = I2S_STD_PHILIPS_SLOT_DEFAULT_CONFIG(I2S_DATA_BIT_WIDTH_32BIT, I2S_SLOT_MODE_STEREO),
        .gpio_cfg = { .mclk = I2S_GPIO_UNUSED, .bclk = PIN_BCK1, .ws = PIN_WS1,
                      .dout = PIN_DOUT1, .din = I2S_GPIO_UNUSED, .invert_flags = {0} },
    };
    ESP_ERROR_CHECK(i2s_channel_init_std_mode(tx1, &s1));
    // slave dulu agar menunggu WS, baru master mulai
    ESP_ERROR_CHECK(i2s_channel_enable(tx1));
    ESP_ERROR_CHECK(i2s_channel_enable(tx0));
    ESP_ERROR_CHECK(i2s_channel_enable(rx0));
}

static inline int32_t f2i(float v) {
    if (v > 0.9999999f) v = 0.9999999f;
    if (v < -1.f) v = -1.f;
    return (int32_t)(v * 2147483648.0f);
}

static void audio_task(void *arg) {
    static chr_t R[NCH];
    static chp_t P[NCH];
    static uint8_t MX[4][2];
    for (int i = 0; i < NCH; i++) {
        R[i].dl = heap_caps_calloc(DLEN, sizeof(float), MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
        if (i >= 2) R[i].fx = heap_caps_calloc(FXLEN, sizeof(float), MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
        if (!R[i].dl || (i >= 2 && !R[i].fx)) { ESP_LOGE(TAG, "PSRAM tidak cukup / tidak aktif"); vTaskDelete(NULL); }
        R[i].gcur = 0; R[i].cg = R[i].ct = R[i].lg = 1;
    }
    g_ca = 1.f - expf(-1.f / (0.005f * FS_HZ));
    g_cr = 1.f - expf(-1.f / (0.120f * FS_HZ));
    taskENTER_CRITICAL(&g_mux); memcpy(P, g_pend, sizeof P); memcpy(MX, g_pmx, sizeof MX); g_dirty = 0; taskEXIT_CRITICAL(&g_mux);

    static int32_t rx[BLOCK * 2], o0[BLOCK * 2], o1[BLOCK * 2];
    static float in[2][BLOCK], out[4][BLOCK];
    float tphase = 0;
    const float blk_us = BLOCK * 1e6f / FS_HZ;
    float cpu = 0;

    for (;;) {
        size_t br = 0;
        if (i2s_channel_read(rx0, rx, sizeof rx, &br, portMAX_DELAY) != ESP_OK) continue;
        int64_t t0 = esp_timer_get_time();
        if (g_dirty) {
            taskENTER_CRITICAL(&g_mux); memcpy(P, g_pend, sizeof P); memcpy(MX, g_pmx, sizeof MX); g_dirty = 0; taskEXIT_CRITICAL(&g_mux);
        }
        float pk[NCH] = {0};
        for (int i = 0; i < BLOCK; i++) {
            float l = rx[2 * i] * (1.f / 2147483648.f), rr = rx[2 * i + 1] * (1.f / 2147483648.f);
#if INPUT_INVERT
            l = -l; rr = -rr;
#endif
#if TEST_TONE
            l = rr = 0.1f * sinf(tphase); tphase += 2.f * (float)M_PI * 1000.f / FS_HZ;
            if (tphase > 2.f * (float)M_PI) tphase -= 2.f * (float)M_PI;
#endif
            in[0][i] = l; in[1][i] = rr;
            if (fabsf(l) > pk[0]) pk[0] = fabsf(l);
            if (fabsf(rr) > pk[1]) pk[1] = fabsf(rr);
        }
        ch_proc(&R[0], &P[0], in[0], 0);
        ch_proc(&R[1], &P[1], in[1], 0);
        for (int k = 0; k < 4; k++) {
            for (int i = 0; i < BLOCK; i++)
                out[k][i] = (MX[k][0] ? in[0][i] : 0.f) + (MX[k][1] ? in[1][i] : 0.f);
            ch_proc(&R[k + 2], &P[k + 2], out[k], 1);
            for (int i = 0; i < BLOCK; i++) { float a = fabsf(out[k][i]); if (a > pk[k + 2]) pk[k + 2] = a; }
        }
        for (int i = 0; i < BLOCK; i++) {
            o0[2 * i] = f2i(out[0][i]); o0[2 * i + 1] = f2i(out[1][i]);
            o1[2 * i] = f2i(out[2][i]); o1[2 * i + 1] = f2i(out[3][i]);
        }
        for (int i = 0; i < NCH; i++) if (pk[i] > g_peak[i]) g_peak[i] = pk[i];
        float used = (float)(esp_timer_get_time() - t0);
        cpu += (used / blk_us * 100.f - cpu) * 0.01f;
        g_cpu = cpu;
        size_t bw;
        i2s_channel_write(tx1, o1, sizeof o1, &bw, portMAX_DELAY);
        i2s_channel_write(tx0, o0, sizeof o0, &bw, portMAX_DELAY);
    }
}

static void unmute_task(void *arg) {
    vTaskDelay(pdMS_TO_TICKS(1000)); gpio_set_level(PIN_XSMT, 1);   // DAC unmute setelah clock stabil
    vTaskDelay(pdMS_TO_TICKS(1000)); gpio_set_level(PIN_RELAY, 1);  // relay amp/speaker (opsional)
    vTaskDelete(NULL);
}

void dsp_start(void) {
    gpio_config_t io = { .pin_bit_mask = (1ULL << PIN_XSMT) | (1ULL << PIN_RELAY), .mode = GPIO_MODE_OUTPUT };
    gpio_config(&io);
    gpio_set_level(PIN_XSMT, 0); gpio_set_level(PIN_RELAY, 0);
    i2s_setup();
    xTaskCreatePinnedToCore(audio_task, "audio", 8192, NULL, configMAX_PRIORITIES - 5, NULL, 1);
    xTaskCreate(unmute_task, "unmute", 2048, NULL, 5, NULL);
    ESP_LOGI(TAG, "I2S %d Hz, blok %d frame", FS_HZ, BLOCK);
}
