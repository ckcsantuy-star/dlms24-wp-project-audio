#pragma once
#include "state.h"

void  dsp_start(void);                 // init I2S + task audio (core 1)
void  dsp_apply(const state_t *s);     // hitung koefisien (thread kontrol), serahkan ke audio task
void  dsp_levels(float db[NCH]);       // peak dBFS sejak panggilan terakhir
float dsp_cpu(void);                   // % beban DSP
float dsp_latency_ms(void);            // perkiraan latensi
