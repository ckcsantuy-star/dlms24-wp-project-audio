#include "state.h"
#include <string.h>
#include <math.h>
#include "nvs.h"

#define STATE_VER 1
static const char *PT[]  = {"PK", "LS", "HS", "NT", "AP"};
static const char *XT[]  = {"BW12", "BW24", "LR12", "LR24", "LR48", "BE12"};
static const char *FXN[] = {"Tanpa", "Echo", "Reverb", "Chorus", "Bass enhancer", "Exciter", "Loudness"};

static float cf(float v, float lo, float hi) { return v < lo ? lo : (v > hi ? hi : v); }
static float nf(const cJSON *o, const char *k, float d) {
    const cJSON *i = cJSON_GetObjectItemCaseSensitive(o, k);
    return cJSON_IsNumber(i) ? (float)i->valuedouble : d;
}
static int fi(const char **tab, int n, const cJSON *it, int d) {
    if (!cJSON_IsString(it)) return d;
    for (int i = 0; i < n; i++) if (!strcmp(tab[i], it->valuestring)) return i;
    return d;
}
static double r2(float v) { return (double)lroundf(v * 100.f) / 100.0; }

static void mk(chs_t *c) {
    memset(c, 0, sizeof *c);
    c->hpf.f = 20; c->lpf.f = 20000;
    c->fa = 50; c->fb = 50; c->th = -12; c->ratio = 1;
    static const float F[8] = {63, 125, 250, 500, 1000, 2000, 4000, 8000};
    for (int i = 0; i < NPEQ; i++) { c->peq[i].t = 0; c->peq[i].f = F[i]; c->peq[i].q = 1; c->peq[i].g = 0; }
}

void state_default(state_t *s) {
    memset(s, 0, sizeof *s);
    s->ver = STATE_VER;
    for (int i = 0; i < NCH; i++) mk(&s->ch[i]);
    s->mx[0][0] = 1; s->mx[1][0] = 1; s->mx[2][1] = 1; s->mx[3][1] = 1;
    strcpy(s->pre, "P02 2-WAY STEREO");
}

bool state_from_json(const cJSON *j, state_t *s) {
    const cJSON *ch = cJSON_GetObjectItemCaseSensitive(j, "ch");
    if (!cJSON_IsArray(ch) || cJSON_GetArraySize(ch) < NCH) return false;
    for (int i = 0; i < NCH; i++) {
        const cJSON *c = cJSON_GetArrayItem(ch, i);
        chs_t *d = &s->ch[i];
        d->gain  = cf(nf(c, "gain", d->gain), -60, 12);
        d->pol   = nf(c, "pol", d->pol) != 0;
        d->mute  = nf(c, "mute", d->mute) != 0;
        const cJSON *h = cJSON_GetObjectItemCaseSensitive(c, "hpf");
        d->hpf.f = cf(nf(h, "f", d->hpf.f), 20, 20000);
        d->hpf.t = fi(XT, 6, cJSON_GetObjectItemCaseSensitive(h, "t"), d->hpf.t);
        const cJSON *l = cJSON_GetObjectItemCaseSensitive(c, "lpf");
        d->lpf.f = cf(nf(l, "f", d->lpf.f), 20, 20000);
        d->lpf.t = fi(XT, 6, cJSON_GetObjectItemCaseSensitive(l, "t"), d->lpf.t);
        d->fx    = fi(FXN, 7, cJSON_GetObjectItemCaseSensitive(c, "fx"), d->fx);
        d->mix   = cf(nf(c, "mix", d->mix), 0, 100);
        d->fa    = cf(nf(c, "fa", d->fa), 0, 100);
        d->fb    = cf(nf(c, "fb", d->fb), 0, 100);
        d->th    = cf(nf(c, "th", d->th), -60, 0);
        d->ratio = cf(nf(c, "ratio", d->ratio), 1, 20);
        d->lim   = cf(nf(c, "lim", d->lim), -24, 0);
        d->dly   = cf(nf(c, "dly", d->dly), 0, 200);
        const cJSON *pq = cJSON_GetObjectItemCaseSensitive(c, "peq");
        for (int b = 0; b < NPEQ && cJSON_IsArray(pq) && b < cJSON_GetArraySize(pq); b++) {
            const cJSON *p = cJSON_GetArrayItem(pq, b);
            peq_t *e = &d->peq[b];
            e->t = fi(PT, 5, cJSON_GetObjectItemCaseSensitive(p, "t"), e->t);
            e->f = cf(nf(p, "f", e->f), 20, 20000);
            e->q = cf(nf(p, "q", e->q), 0.1f, 20);
            e->g = cf(nf(p, "g", e->g), -15, 15);
        }
    }
    const cJSON *mx = cJSON_GetObjectItemCaseSensitive(j, "mx");
    for (int k = 0; k < 4 && cJSON_IsArray(mx) && k < cJSON_GetArraySize(mx); k++) {
        const cJSON *r = cJSON_GetArrayItem(mx, k);
        for (int m = 0; m < 2 && cJSON_IsArray(r) && m < cJSON_GetArraySize(r); m++) {
            const cJSON *v = cJSON_GetArrayItem(r, m);
            if (cJSON_IsNumber(v)) s->mx[k][m] = v->valuedouble != 0;
        }
    }
    const cJSON *pre = cJSON_GetObjectItemCaseSensitive(j, "pre");
    if (cJSON_IsString(pre)) { strncpy(s->pre, pre->valuestring, sizeof s->pre - 1); s->pre[sizeof s->pre - 1] = 0; }
    s->ver = STATE_VER;
    return true;
}

cJSON *state_to_json(const state_t *s) {
    cJSON *root = cJSON_CreateObject(), *ch = cJSON_AddArrayToObject(root, "ch");
    for (int i = 0; i < NCH; i++) {
        const chs_t *c = &s->ch[i];
        cJSON *o = cJSON_CreateObject();
        cJSON_AddNumberToObject(o, "gain", r2(c->gain));
        cJSON_AddNumberToObject(o, "pol", c->pol);
        cJSON_AddNumberToObject(o, "mute", c->mute);
        cJSON *h = cJSON_AddObjectToObject(o, "hpf");
        cJSON_AddNumberToObject(h, "f", lroundf(c->hpf.f)); cJSON_AddStringToObject(h, "t", XT[c->hpf.t % 6]);
        cJSON *l = cJSON_AddObjectToObject(o, "lpf");
        cJSON_AddNumberToObject(l, "f", lroundf(c->lpf.f)); cJSON_AddStringToObject(l, "t", XT[c->lpf.t % 6]);
        cJSON_AddStringToObject(o, "fx", FXN[c->fx % 7]);
        cJSON_AddNumberToObject(o, "mix", r2(c->mix));
        cJSON_AddNumberToObject(o, "fa", r2(c->fa));
        cJSON_AddNumberToObject(o, "fb", r2(c->fb));
        cJSON_AddNumberToObject(o, "th", r2(c->th));
        cJSON_AddNumberToObject(o, "ratio", r2(c->ratio));
        cJSON_AddNumberToObject(o, "lim", r2(c->lim));
        cJSON_AddNumberToObject(o, "dly", r2(c->dly));
        cJSON *pq = cJSON_AddArrayToObject(o, "peq");
        for (int b = 0; b < NPEQ; b++) {
            cJSON *p = cJSON_CreateObject();
            cJSON_AddStringToObject(p, "t", PT[c->peq[b].t % 5]);
            cJSON_AddNumberToObject(p, "f", lroundf(c->peq[b].f));
            cJSON_AddNumberToObject(p, "q", r2(c->peq[b].q));
            cJSON_AddNumberToObject(p, "g", r2(c->peq[b].g));
            cJSON_AddItemToArray(pq, p);
        }
        cJSON_AddItemToArray(ch, o);
    }
    cJSON *mx = cJSON_AddArrayToObject(root, "mx");
    for (int k = 0; k < 4; k++) {
        cJSON *r = cJSON_CreateArray();
        cJSON_AddItemToArray(r, cJSON_CreateNumber(s->mx[k][0]));
        cJSON_AddItemToArray(r, cJSON_CreateNumber(s->mx[k][1]));
        cJSON_AddItemToArray(mx, r);
    }
    cJSON_AddStringToObject(root, "pre", s->pre);
    return root;
}

bool state_save(const char *key, const state_t *s) {
    nvs_handle_t h;
    if (nvs_open("dlms", NVS_READWRITE, &h) != ESP_OK) return false;
    esp_err_t e = nvs_set_blob(h, key, s, sizeof *s);
    if (e == ESP_OK) e = nvs_commit(h);
    nvs_close(h);
    return e == ESP_OK;
}

bool state_load(const char *key, state_t *s) {
    nvs_handle_t h;
    if (nvs_open("dlms", NVS_READONLY, &h) != ESP_OK) return false;
    size_t n = sizeof *s;
    state_t t;
    esp_err_t e = nvs_get_blob(h, key, &t, &n);
    nvs_close(h);
    if (e != ESP_OK || n != sizeof t || t.ver != STATE_VER) return false;
    *s = t;
    return true;
}
