#pragma once
// ===== DLMS-24 · WP PROJECT AUDIO · konfigurasi =====
#define FS_HZ        48000
#define BLOCK        32      // frame per blok DSP (32 = 0,67 ms)
#define DMA_DESC     4
#define NCH          6       // IN A, IN B, OUT1..OUT4
#define NPEQ         8
#define NSLOT        16      // 8 PEQ + 4 HPF + 4 LPF (biquad)

// ---- Pin ESP32-S3 (aman untuk modul N16R8: hindari GPIO26-37) ----
#define PIN_MCLK     4       // -> PCM1808 SCK (256fs = 12,288 MHz)
#define PIN_BCK      5       // -> PCM1808 BCK, DAC1 BCK, DAC2 BCK, + jumper ke GPIO16
#define PIN_WS       6       // -> PCM1808 LRC , DAC1 LCK, DAC2 LCK, + jumper ke GPIO17
#define PIN_DOUT0    7       // -> DAC1 DIN (OUT1/OUT2)
#define PIN_DIN      15      // <- PCM1808 OUT
#define PIN_BCK1     16      // masukan BCK untuk I2S1 (slave), kawat dari net BCK
#define PIN_WS1      17      // masukan WS  untuk I2S1 (slave), kawat dari net WS
#define PIN_DOUT1    18      // -> DAC2 DIN (OUT3/OUT4)
#define PIN_XSMT     8       // -> XSMT kedua DAC (soft-mute, high = bunyi)
#define PIN_RELAY    2       // opsional: relay mute speaker/amp (high = aktif)
#define PIN_LED      21
#define PIN_BTN      14      // tahan saat boot 3 dtk = reset WiFi

// ---- Opsi ----
#define CLK_MASTER_EXT  0    // 1 = osilator 12,288 MHz eksternal; PCM1808 master, ESP slave (lihat README)
#define INPUT_INVERT    1    // 1 = buffer input membalik fasa (op-amp inverting), dikoreksi di DSP
#define TEST_TONE       0    // 1 = sinus 1 kHz -20 dBFS pada kedua input (uji bring-up)

#define AP_SSID      "DLMS-24"
#define AP_PASS      "wpaudio24"   // GANTI sebelum dipakai (min 8 karakter)
