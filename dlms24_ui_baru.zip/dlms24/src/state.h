#pragma once
#include <stdint.h>
#include <stdbool.h>
#include "cJSON.h"
#include "config.h"

// t: 0 PK, 1 LS, 2 HS, 3 NT, 4 AP
typedef struct { uint8_t t; float f, q, g; } peq_t;
// t: 0 BW12, 1 BW24, 2 LR12, 3 LR24, 4 LR48, 5 BE12
typedef struct { float f; uint8_t t; } xo_t;
// fx: 0 Tanpa,1 Echo,2 Reverb,3 Chorus,4 Bass enhancer,5 Exciter,6 Loudness
typedef struct {
    float gain; uint8_t pol, mute, fx; xo_t hpf, lpf;
    float mix, fa, fb, th, ratio, lim, dly;
    peq_t peq[NPEQ];
} chs_t;

typedef struct {
    uint16_t ver;
    chs_t ch[NCH];
    uint8_t mx[4][2];
    char pre[40];
} state_t;

void    state_default(state_t *s);
bool    state_from_json(const cJSON *j, state_t *s);   // s dipakai sebagai nilai default
cJSON  *state_to_json(const state_t *s);
bool    state_save(const char *key, const state_t *s);
bool    state_load(const char *key, state_t *s);
