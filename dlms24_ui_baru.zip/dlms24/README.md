# DLMS-24 · WP PROJECT AUDIO
Digital Loudspeaker Management System, 2 input / 4 output, 48 kHz, dikontrol penuh lewat HP (WiFi + web UI).

> **Status jujur:** firmware ini ditulis lengkap tetapi **belum saya kompilasi / uji di hardware**. Siapkan waktu untuk perbaikan kecil saat build pertama, dan lakukan uji bertahap (bagian 7). Nilai komponen analog adalah titik awal, verifikasi dengan datasheet modul yang Anda beli.

## 1. Arsitektur
- **ADC:** PCM1808 (stereo) → IN A, IN B.
- **DAC:** PCM5102 hanya stereo, jadi untuk 4 output dipakai **2 modul PCM5102** (OUT1/2 dan OUT3/4).
- **ESP32-S3:** I2S0 master full-duplex (MCLK/BCK/WS, DOUT0 ke DAC1, DIN dari ADC). I2S1 slave TX ke DAC2, memakai BCK/WS yang sama lewat 2 kawat jumper (GPIO16, GPIO17). Semua clock dari satu sumber, jadi 4 output sinkron.
- **DSP (core 1, blok 32 frame):** PEQ 8 band (PK/LS/HS/NT/AP) → HPF/LPF (BW12/24, LR12/24/48, Bessel) → [output saja: FX → kompresor] → delay ≤200 ms → gain/polaritas/mute → [output: limiter]. Matrix routing A/B → OUT1–4 di antara input dan output.
- **Jaringan:** ESP32 membuat WiFi `DLMS-24` (password di `config.h`), buka `http://192.168.4.1`. Opsional tersambung ke WiFi rumah (menu Setup). UI dan firmware bicara lewat WebSocket `/ws` (JSON), level meter 30×/detik.
- Pengaturan terakhir tersimpan otomatis (3 dtk setelah perubahan); slot user 1–32 di flash.

## 2. Daftar komponen (BOM)
| Qty | Komponen | Catatan |
|---|---|---|
| 1 | ESP32-S3-DevKitC-1U-N16R8 (atau modul WROOM-1U-N16R8) | versi **U** = konektor IPEX, PSRAM octal 8 MB wajib |
| 1 | Antena 2,4 GHz SMA + pigtail IPEX→SMA | pasang sebelum power on |
| 1 | Modul ADC PCM1808 | catu 5 V + 3,3 V |
| 2 | Modul DAC PCM5102A (GY-PCM5102) | |
| 1 | Op-amp dual RRIO 5 V (OPA2376, atau setara noise rendah) | buffer input |
| 1 | LDO 3,3 V noise rendah (LP5907-3.3 breakout) | untuk 3V3_A |
| 1 | Adaptor 5 V DC ≥ 2 A + soket DC | atau USB-C 5 V |
| 1 | PTC 1,1 A, kapasitor 470 µF/16 V | proteksi + bulk |
| 1 | Ferrite bead 600 Ω@100 MHz | pemisah 5V_D / 5V_A |
| 3 | 33 Ω (MCLK, BCK, WS) | seri, dekat ESP32 |
| 2 | 10 kΩ + 47 µF | Vbias 2,5 V |
| 2 | Per kanal input: 10 kΩ (Rin), 4,7 kΩ (Rf), 100 pF, 1 kΩ, 4,7 µF film (masuk), 2,2 µF film (ke ADC) | ×2 kanal |
| 4 | Per kanal output: 100 Ω seri, 2,2 µF film, 47 kΩ ke GND | ×4 kanal |
| 2+4 | Jack input (6,35 TRS/RCA) dan jack output | |
| – | Kapasitor 100 nF (×10), 10 µF (×6), 100 µF (×2) | decoupling |
| 1 | LED + 330 Ω, tombol (GPIO14→GND) | status, reset WiFi |
| opsional | Relay 5 V + transistor BC547/2N2222 + 1N4148 + 4,7 kΩ | mute amp saat boot (GPIO2) |
| opsional | Osilator 12,288 MHz (3,3 V) | clock lebih bersih, lihat bagian 8 |
| – | PCB/perfboard, kabel pendek, casing logam ter-ground | |

## 3. Peta pin ESP32-S3
| GPIO | Fungsi | Tujuan |
|---|---|---|
| 4 | MCLK 12,288 MHz | PCM1808 **SCK** (via 33 Ω) |
| 5 | BCK | PCM1808 BCK, DAC1 BCK, DAC2 BCK, **dan** kawat ke GPIO16 |
| 6 | WS / LRCK | PCM1808 LRC, DAC1 LCK, DAC2 LCK, **dan** kawat ke GPIO17 |
| 7 | I2S0 DOUT | DAC1 **DIN** (OUT1/OUT2) |
| 15 | I2S0 DIN | PCM1808 **OUT** |
| 16 | BCK1 (input) | dari net BCK (kawat jumper) |
| 17 | WS1 (input) | dari net WS (kawat jumper) |
| 18 | I2S1 DOUT | DAC2 **DIN** (OUT3/OUT4) |
| 8 | XSMT | XSMT kedua DAC (low = mute saat boot, high setelah 1 dtk) |
| 2 | RELAY | transistor relay mute amp (high setelah 2 dtk), opsional |
| 21 | LED | LED + 330 Ω ke GND |
| 14 | Tombol | ke GND; tahan 3 dtk saat boot = hapus WiFi rumah |

Jangan pakai GPIO 26–37 (flash/PSRAM octal) dan hindari 0, 3, 45, 46 (strapping). Perubahan pin ada di `src/config.h`.

## 4. Wiring modul
**PCM1808:** SCK←GPIO4, BCK←GPIO5, LRC←GPIO6 (masing-masing via 33 Ω), OUT→GPIO15, **FMT=GND** (I2S), **MD0=GND, MD1=GND** (slave, auto 256/384/512fs), VCC=5V_A, VDD (3V3)=3V3_A, GND=AGND. Input kiri/kanan dari input stage lewat 2,2 µF (jika modul sudah punya kopling dan filter, jangan dobel).

**PCM5102 #1 dan #2:** BCK←GPIO5, LCK←GPIO6, DIN←GPIO7 (#1) atau GPIO18 (#2), **SCK=GND** (solder bridge, PLL internal), FLT=L, DEMP=L, FMT=L (I2S), **XSMT**: lepas jumper H3L, sambung ke GPIO8. VIN sesuai silkscreen modul (umumnya 3,3 V dari 3V3_A; ukur 3,3 V di chip). OUTL/OUTR ke output stage.

**Input stage per kanal (single supply 5V_A, op-amp inverting):**
```
Jack tip ─ 4,7µF ─ 10k ─┬─(−) op-amp ── out ─ 2,2µF ─ VIN ADC
                        │       ▲
                   4,7k ┴ 100pF ┘ (Rf)
(+) op-amp ─ 1k ─ Vbias 2,5V  (10k/10k dari 5V_A + 47µF)
Jack sleeve ─ AGND
```
Gain −0,47. Perkiraan 0 dBFS ≈ 2,2 Vrms input bila full-scale ADC ≈ 3 Vpp (**cek datasheet PCM1808**, sesuaikan Rf). Fasa terbalik oleh op-amp dikoreksi firmware (`INPUT_INVERT 1`; set 0 jika tanpa op-amp inverting).

**Output per kanal:** `OUT modul ─ 100 Ω ─ 2,2 µF ─ jack tip`, `47 kΩ` dari jack tip ke GND. PCM5102 menghasilkan ±2,1 Vrms ground-referenced, cukup untuk input power amp. Untuk output balanced tambahkan driver line (mis. DRV135/THAT1646).

## 5. Catu daya dan grounding
```
5V DC → PTC → 470µF → 5V_D ─┬→ pin 5V ESP32, relay
                            └→ ferrite → 100µF+100nF → 5V_A ─┬→ PCM1808 VCC, OPA2376
                                                              └→ LP5907 → 3V3_A → PCM1808 VDD, PCM5102 ×2
```
- Ground **bintang**: AGND dan DGND bertemu di satu titik dekat PCM1808.
- Kabel MCLK/BCK/WS pendek (<10 cm), pilin dengan kawat GND.
- Casing logam ke ground chassis, input shield ke AGND saja.

## 6. Build dan flash
1. Pasang PlatformIO (VS Code). Buka folder ini.
2. Ganti `AP_PASS` di `src/config.h`.
3. Untuk modul **N8R8/N8 tanpa 16 MB**: ubah flash size di `platformio.ini`, `sdkconfig.defaults`, dan perkecil ota di `partitions.csv`. PSRAM wajib untuk delay dan FX.
4. `pio run -t upload`, lalu `pio device monitor`. Log `DLMS-24 siap` muncul bila sukses.
5. HP: sambung WiFi `DLMS-24`, buka `http://192.168.4.1`. Menu Setup → "Simpan dan sambungkan" untuk WiFi rumah (IP baru tampil di Setup).
6. Update firmware via OTA: `curl --data-binary @.pio/build/dlms24/firmware.bin http://192.168.4.1/update`.

## 7. Uji bertahap (jangan sambung amp dulu)
1. ESP32 saja: AP muncul, UI terbuka, status "Terhubung ke DLMS".
2. Set `TEST_TONE 1`, tambahkan DAC1 lalu DAC2: nada 1 kHz di OUT1–4 (pakai headphone/amp kecil). Matikan setelah selesai.
3. Pasang PCM1808 tanpa input: meter IN sekitar −∞. Beri sinyal line, cek meter IN A/B bergerak dan tidak clip.
4. Sinkron OUT1–4: beri sinyal sama ke 4 output, cek di osiloskop atau lewat delay trim di UI.
5. Baru sambung amp dan speaker.

## 8. Catatan penting
- **Keamanan speaker:** firmware boot memakai preset terakhir (default: full-range, tanpa crossover). **Atur crossover/HPF dan limiter dulu sebelum menyambung tweeter**; pakai relay mute (GPIO2) atau matikan amp saat menyalakan perangkat.
- **Clock:** default ESP32 jadi master; MCLK 12,288 MHz dari pembagi pecahan sehingga ada jitter kecil. Untuk kualitas terbaik: osilator 12,288 MHz ke SCK PCM1808, PCM1808 mode master 256fs (MD1=MD0=1), BCK/LRCK PCM1808 ke net BCK/WS dan GPIO5/6 dilepas dari output, set `CLK_MASTER_EXT 1`. Mode ini belum saya uji.
- **Latensi:** UI menampilkan perkiraan (~3,5 ms). Ukur sendiri dengan loopback.
- **PIN lock** di UI hanya tampilan; keamanan akses nyata adalah password WPA2 AP.
- **Meter:** IN = level ADC sebelum DSP, OUT = setelah DSP/limiter.
- Mengubah delay saat audio jalan bisa menimbulkan klik kecil.

## 9. Troubleshooting
| Gejala | Cek |
|---|---|
| Tidak ada suara | XSMT (GPIO8 high?), SCK DAC ke GND, FMT=I2S, sambungan BCK/WS |
| OUT3/4 mati, OUT1/2 jalan | kawat GPIO16/17 dari net BCK/WS, DIN DAC2 ke GPIO18 |
| Desis/dengung | ground bintang, kabel clock pendek, 33 Ω seri, LDO 3V3_A |
| Meter IN selalu −∞ | PCM1808 FMT/MD pin, SCK/MCLK, Vbias, VCC 5 V |
| Output terdengar fasa terbalik | ubah `INPUT_INVERT` |
| UI "Mode demo" | WebSocket putus; muat ulang, pastikan terhubung ke WiFi DLMS-24 |
| PSRAM error di log | pakai modul R8, cek `CONFIG_SPIRAM_MODE_OCT` |

## 10. Protokol WebSocket (`/ws`, JSON)
Klien → perangkat: `state` {s}, `save` {n}, `load` {n}, `wifi` {ssid,pass}.
Perangkat → klien: `hi` {id}, `state` {s,from}, `m` {v[6] dBFS}, `cpu` {v,lat}, `info` {ip,mode}, `toast` {m}.
Skema `s` identik dengan objek `S` di UI (ch[6], mx[4][2], pre).
